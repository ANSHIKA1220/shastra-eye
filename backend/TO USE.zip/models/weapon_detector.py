# models/weapon_detector.py
import torch
import cv2
from ultralytics import YOLO

class WeaponDetector:
    def __init__(self):
        self.model = YOLO("models/yolov8_weights.pt")

    def detect(self, frame):
        results = self.model(frame)
        for r in results:
            for box in r.boxes:
                cls = r.names[int(box.cls[0])]
                if cls in ["knife", "gun"]:
                    return True
        return False