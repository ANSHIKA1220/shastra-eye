import torch
import cv2

class TheftDetector:
    def __init__(self):
        self.model = torch.load("models/theft_model.pt", map_location="cpu")
        self.model.eval()

    def detect(self, frame):
        frame_resized = cv2.resize(frame, (224, 224))
        tensor = torch.from_numpy(frame_resized).permute(2, 0, 1).unsqueeze(0).float() / 255.0
        with torch.no_grad():
            prediction = self.model(tensor)
            return prediction.argmax().item() == 1
